using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;   // 如果用旧版 Text 需要这句

public class VictoryManager : MonoBehaviour
{
    public GameObject victoryPanel;   // 拖入 VictoryPanel 对象
    public Button nextLevelButton;    // 拖入 NextLevelButton 对象

    private string nextSceneName;     // 下一个要加载的场景名

    void Start()
    {
        // 一开始胜利界面隐藏
        if (victoryPanel != null)
            victoryPanel.SetActive(false);

        // 给按钮绑定点击事件
        if (nextLevelButton != null)
            nextLevelButton.onClick.AddListener(LoadNextLevel);
    }

    // 显示胜利界面，并传入下一关的名字
    public void ShowVictory(string nextScene)
    {
        nextSceneName = nextScene;
        if (victoryPanel != null)
            victoryPanel.SetActive(true);
        
        // 可选：暂停游戏时间（让玩家无法移动）
        Time.timeScale = 0f;
    }

    // 加载下一关
    void LoadNextLevel()
    {
        // 恢复时间
        Time.timeScale = 1f;
        // 加载场景
        SceneManager.LoadScene(nextSceneName);
    }
}