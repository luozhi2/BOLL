using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject mainMenuPanel;
    
    void Start()
    {
        if (mainMenuPanel != null)
            mainMenuPanel.SetActive(true);
    }
    
    public void StartGame()
    {
        Debug.Log("开始游戏！");
        SceneManager.LoadScene("Game");
    }
    
    public void QuitGame()
    {
        Debug.Log("退出游戏");
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
}