using UnityEngine;
using TMPro; // 引入命名空间以使用TextMeshPro

public class CollectibleItem : MonoBehaviour
{
    public int scoreValue = 10; // 可自由调整此物品的加分值
    public TextMeshProUGUI scoreText; // 引用显示分数的UI文本

    // 当其他碰撞体进入物品的触发器时，自动调用此方法
    void OnTriggerEnter(Collider other)
    {
        // 检查进入触发器的物体是否为玩家
        if (other.CompareTag("Player"))
        {
            // 增加分数
            int currentScore = int.Parse(scoreText.text.Split(' ')[1]); // 从文本解析当前分数
            currentScore += scoreValue;
            
            // 更新UI文本
            scoreText.text = "Score: " + currentScore;
            
            // 可选：播放收集音效或特效
            // 可选：Destroy(this.gameObject); // 如需触碰后物品消失，取消这行注释
        }
    }
}