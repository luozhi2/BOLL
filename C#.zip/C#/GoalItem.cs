using UnityEngine;

public class GoalItem : MonoBehaviour
{
    // 在 Inspector 中设置下一关的名字，比如 "Level2"
    public string nextLevelName = "Level2";

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // 找到 VictoryManager（假设它挂载在 VictoryCanvas 上）
            VictoryManager vm = FindObjectOfType<VictoryManager>();
            if (vm != null)
            {
                vm.ShowVictory(nextLevelName);
            }
            else
            {
                Debug.LogError("场景中没有 VictoryManager！请检查 VictoryCanvas。");
            }
        }
    }
}